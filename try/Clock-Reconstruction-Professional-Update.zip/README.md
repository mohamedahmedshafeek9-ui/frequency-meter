# Multiplexed clock/display controller — KiCad draft

## Project files

Open `clock_display_visual_draft.kicad_pro` in KiCad 10.0.3. The project includes the editable schematic, the custom 74260 library, project-local symbol/footprint tables, and a KiCad-rendered SVG preview.

| File | Purpose |
|---|---|
| `clock_display_visual_draft.kicad_pro` | KiCad project |
| `clock_display_visual_draft.kicad_sch` | Editable schematic |
| `Clock_Reconstruction.kicad_sym` | Custom 74260 dual five-input NOR symbol |
| `sym-lib-table`, `fp-lib-table` | Project-local symbol and footprint library mappings for this KiCad installation |
| `preview/clock_display_visual_draft.svg` | Rendered schematic preview |

## Changes made

The former resistor packs RN1–RN4 were removed and replaced with **32 individual 220 Ω resistors**, one for each a–g and decimal-point segment node across the four digits. Per your clarified instruction, each resistor is connected from that segment node to the common GND net. The netlist confirms the resistor’s first pin is on its segment node and its second pin is on GND.

U18 is the project-local custom **74260 dual five-input NOR** symbol using the supplied pinout: gate 1 inputs 1, 2, 3, 12, 13 → output 5; gate 2 inputs 4, 8, 9, 10, 11 → output 6; GND pin 7; VCC pin 14. U18 pin 5 now connects to U21 pin 1. U21 pin 3 feeds U26’s inverter input, and U26 pin 2 connects to the 74193 DOWN input U22 pin 4; these nets were checked in the exported netlist. U18 uses a DIP-14_W7.62mm footprint; select another package only if it matches the physical part.

U28 is an L7805CV regulator with a two-pin external DC input connector J1 (`VIN`, `gnd`), 330 nF input bypass capacitor C1, and 100 nF output capacitor C2. Its output is the shared `vcc` rail and its return is `gnd`. The 17 multi-unit IC power sections are now placed, and the netlist confirms their VCC pins join U28 output and their GND pins join the common ground. The external source itself is not specified or connected; choose a suitable input voltage and check regulator dissipation for the load.

The existing digit anode selection and BCD chain remain. P1–P4 connect the four display common-anode pins to U25. The lower counters feed their respective 4511 drivers, and the upper six-stage 74HC390 divider chain starts from the 10 MHz Y1 oscillator. The 4511 control pins, U22 a/b/c selector nets, and U21-to-DOWN path are labeled as shown. Thin section frames and headings now separate timebase, digit selection/display, control/reset, BCD/driver, regulated-power, and IC-power areas.

## Electrical review required — do not power yet

The requested resistor topology is a **shunt from each segment node to GND**, not a series current-limiting resistor. This may load the 4511 outputs and does not by itself provide safe LED current limiting. Also verify the common-anode displays are compatible with the 4511 outputs and the digit-driver polarity. Do not energize the circuit until the display-drive stage is checked and corrected as needed.

KiCad exports the schematic and netlist successfully. ERC currently reports **193 violations**: 47 unconnected pins, 31 undriven inputs, 71 symbol/library mismatches, 16 isolated pin labels, 14 missing input pins, and 14 unplaced units. Some remaining logic and several reference-image connections are still unresolved. The 7805CV input supply and physical connector/footprints also need confirmation. This is a reconstruction draft, not a validated or fabrication-ready design.
