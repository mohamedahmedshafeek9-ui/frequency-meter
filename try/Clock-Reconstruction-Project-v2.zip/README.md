# KiCad clock/display reconstruction (draft)

## Project files

| File | Purpose |
|---|---|
| `clock_display_visual_draft.kicad_pro` | KiCad project file |
| `clock_display_visual_draft.kicad_sch` | Editable schematic sheet |
| `Clock_Reconstruction.kicad_sym` and `sym-lib-table` | Project-local custom 74260 symbol library |
| `preview/clock_display_visual_draft.svg` | KiCad-rendered preview |

Open the `.kicad_pro` file in KiCad 10.0.3; its base name matches the schematic.

## Reconstructed connections

U18 is a project-local custom **74260 dual 5-input NOR** symbol using the pinout from the supplied specifications image: gate 1 inputs 1, 2, 3, 12, 13 → output 5; gate 2 inputs 4, 8, 9, 10, 11 → output 6; GND pin 7; VCC pin 14. U18:A and its power unit are placed; U18:B remains available in the library. U18 pin 5's destination is still unconfirmed. The assigned footprint is DIP-14_W7.62mm; choose SOIC-14 only if that matches the physical component.

The four display digits' common-anode pins 3 and 14 are connected to U25's first four decoder outputs with labels P1–P4. Each matching RN resistor-pack common is on that same P net. RN1–RN4 values are **220 Ω**. For each digit, RN pins R1–R7 map to segments a–g and R8 maps to the decimal point (`dp1`–`dp4`). The 4511 output/segment mapping is U23→digit 1, U9→digit 2, U14→digit 3, and U16→digit 4.

The four lower 74HC390 counters feed the corresponding 4511 BCD inputs: U11→U23, U10→U9, U8→U14, and U17→U16. Q0–Q3 connect to inputs A–D; Q0 also feeds CKB for divide-by-10 operation. The Q3 carry cascade runs from digit 4 to 3 to 2 to 1. The counter chain is driven from the AND OUT signal at U17.

Y1 is a four-pin 10 MHz active oscillator replacing the former clock symbol. Its output pin 3 drives U2:A through `CLK_10M`; pin 2 is GND, pin 4 is VCC, and pin 1 EN is tied high under the assumed active-high enable convention. Six upper 74HC390 sections are cascaded as decade dividers (U2:A, U2:B, U3:A, U3:B, U4:A, U4:B), with Q0-to-CKB feedback and MR held low. U2:A/B Q outputs feed the U5 X0–X7 mux inputs. U22 QA/QB/QC provide the shared a/b/c select/address nets for U5 and U25. U5 Z feeds U13's `AND IN`; the U21 output is wired to U26's inverter input. The four 4511 lamp-test/latch controls are tied to VCC/GND as shown, with BI on the shared `you` net.

## Remaining checks

KiCad successfully exports the schematic to SVG and netlist. ERC currently reports **200 violations**, including unconnected or undriven pins, missing power units, unused units, and library/footprint metadata warnings. The U5 complement output, the 74260 output, some control logic, and several pins visible in the reference still need confirmation. The display part's polarity and exact oscillator part/package are also unconfirmed. This is a reconstruction draft, not a validated circuit: do not fabricate or power it until the remaining nets are confirmed and ERC is resolved.
